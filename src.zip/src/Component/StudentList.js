import React, { Component } from "react";
import axios from "axios";

class StudentList extends Component {
  state = {
    students: [],
  };

  componentDidMount = () => {
    //server side code start from here...
    let url = "http://localhost:8080/student-details";

    axios.get(url).then((response) => {
      console.log(response.data);
      this.setState({
        students: response.data,
      });
    });
  };
  render() {
    let getStudents = this.state.students.map((student) => {
      return (
        <tr>
          <td>{student.studentID}</td>
          <td>{student.studentName}</td>
          <td>{student.address}</td>
          <td>{student.mobileNumber}</td>
          <td>{student.totalMarks}</td>
          <td>{student.obtainedMarks}</td>
          <td>{(student.obtainedMarks / student.totalMarks) * 100}</td>
          <td>
            {(student.obtainedMarks / student.totalMarks) * 100 >= 35
              ? "Pass"
              : "Fail"}
          </td>
        </tr>
      );
    });
    return (
      <div>
        <div>
          <h4 className="text-center mt-4 ">Students Details</h4>
          <form className="form my-2 my-lg-0 ">
            <input
              className="form-control d-inline mr-sm-2 w-25"
              type="search"
              placeholder=" Type Here...."
              aria-label="Search"
              style={{
                float: "right",
                position: "relative",
                right: "100px",
                bottom: "10px",
              }}
            />
            <button
              className="btn btn-outline-success d-inline my-2 my-sm-0"
              type="submit"
              style={{
                float: "right",
                position: "relative",
                left: "300px",
                bottom: "10px",
              }}
            >
              Search
            </button>
          </form>
          <table className="table table-secondary table-hover table-bordered shadow-lg mt-3">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Address</th>
                <th>Mobile</th>
                <th>Total Marks</th>
                <th>Obtained Marks</th>
                <th>Percentage</th>
                <th>Remarks</th>
              </tr>
            </thead>
            <tbody>{getStudents}</tbody>
          </table>
        </div>
        <nav
          aria-label="Page navigation example"
          style={{ position: "relative", top: "20px" }}
        >
          <ul className="pagination justify-content-center ">
            <li className="page-item">
              <a className="page-link" href="#">
                Previous
              </a>
            </li>
            <li className="page-item">
              <a className="page-link" href="#">
                1
              </a>
            </li>
            <li className="page-item">
              <a className="page-link" href="#">
                2
              </a>
            </li>
            <li className="page-item">
              <a className="page-link" href="#">
                ...
              </a>
            </li>
            <li className="page-item">
              <a className="page-link" href="#">
                Next
              </a>
            </li>
          </ul>
        </nav>
      </div>
    );
  }
}

export default StudentList;
