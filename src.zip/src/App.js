import './App.css';
import StudentList from './Component/StudentList';

function App() {
  return (
    <div className="App">
    <StudentList></StudentList>
    </div>
  );
}

export default App;
