package com.studentsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
