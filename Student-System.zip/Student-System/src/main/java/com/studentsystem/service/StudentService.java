package com.studentsystem.service;

import com.studentsystem.entity.Student;

import java.util.List;

public interface StudentService {
    List<Student> getAllStudents();

}
